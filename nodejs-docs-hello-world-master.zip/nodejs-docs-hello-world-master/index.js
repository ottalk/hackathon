var express = require('express');
var app = express();
var port=5000;
var bodyParser = require("body-parser");

var sql = require("mssql");

// config for your database
var config = {
      server: 'chilisqlserver.database.windows.net',  //update me
      authentication: {
          type: 'default',
          options: {
              userName: 'chiliuser@chilisqlserver', //update me
              password: 'Chiliteam2019'  //update me
          }
      },
      options: {
          // If you are on Microsoft Azure, you need encryption:
          encrypt: true,
          database: 'mssqldatabase'  //update me
      }
};


app.get('/getUsers', function (req, res) {
  // connect to your database
  sql.connect(config, function (err) {
    if (err) console.log(err);
    // create Request object
    var request = new sql.Request();
    // query to the database and get the records
    request.query('select * from Users', function (err, recordset) {
        if (err) console.log(err)
        // send records as a response
        res.send(recordset);
    });
  });
});

var server = app.listen(5000, function () {
console.log('Server is running..');
});


console.log("Server running at http://localhost:%d", port);
