//        user: 'chiliuser@chilisqlserver',
//        password: 'Chiliteam2019',
//        server: 'chilisqlserver.database.windows.net',
//        database: 'mssqldatabase',

    var Connection = require('tedious').Connection;
    var config = {
        server: 'chilisqlserver.database.windows.net',  //update me
        authentication: {
            type: 'default',
            options: {
                userName: 'chiliuser@chilisqlserver', //update me
                password: 'Chiliteam2019'  //update me
            }
        },
        options: {
            // If you are on Microsoft Azure, you need encryption:
            encrypt: true,
            database: 'mssqldatabase'  //update me
        }
    };
    var connection = new Connection(config);
    connection.on('connect', function(err) {
        // If no error, then good to proceed.
        console.log("Connected");
        executeStatement();
    });

    var Request = require('tedious').Request;
    var TYPES = require('tedious').TYPES;

    function executeStatement() {
        request = new Request("SELECT * from Users;", function(err) {
        if (err) {
            console.log(err);}
        });
        var result = "";
        request.on('row', function(columns) {
            columns.forEach(function(column) {
              if (column.value === null) {
                console.log('NULL');
              } else {
                result+= column.value + " ";
              }
            });
            console.log(result);
            result ="";
        });

        request.on('done', function(rowCount, more) {
        console.log(rowCount + ' rows returned');
        });
        connection.execSql(request);
    }
